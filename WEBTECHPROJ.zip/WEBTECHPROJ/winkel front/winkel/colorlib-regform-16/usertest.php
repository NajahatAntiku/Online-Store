<?php
require('signupclass.php');
require('vendorsignup.php');

function regU($fname, $lname, $password, $email, $phonenumber){
	$addtodb = new shopper;

	$ifadded = $addtodb->addNewUser($fname, $lname, $password, $email, $phonenumber);
	if ($ifadded) {
		return $ifadded;
	}else{
		return false;
	}
}

function regS($fname, $lname, $password, $email, $phonenumber, $nameofsh, $categoryofsh){
	$addtodb = new vendor;
	$ifadded = $addtodb->addNewSupplier($fname, $lname, $password, $email, $phonenumber, $nameofsh, $categoryofsh);
	if ($ifadded) {
		return $ifadded;

	}else{
		return false;
	}
}

function post($product_name, $Price){
	$addtodb = new vendor;
	$ifadded = $addtodb->addProductInfo($product_name, $Price);
	if ($ifadded) {
		return $ifadded;

	}else{
		return false;
	}
 
}


?>