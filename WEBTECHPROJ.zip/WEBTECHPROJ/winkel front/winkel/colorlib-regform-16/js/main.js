(function($) {

  $('#mem_type').parent().append('<ul class="list-item" id="newmem_type" name="mem_type"></ul>');
  $('#mem_type option').each(function(){
      $('#newmem_type').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
  });
  $('#mem_type').remove();
  $('#newmem_type').attr('id', 'mem_type');
  $('#mem_type li').first().addClass('init');
  $("#mem_type").on("click", ".init", function() {
      $(this).closest("#mem_type").children('li:not(.init)').toggle();
  });
  
  var allOptions = $("#mem_type").children('li:not(.init)');
  $("#mem_type").on("click", "li:not(.init)", function() {
      allOptions.removeClass('selected');
      $(this).addClass('selected');
      $("#mem_type").children('.init').html($(this).html());
      allOptions.toggle();
  });

  var marginSlider = document.getElementById('slider-margin');
  if (marginSlider != undefined) {
      noUiSlider.create(marginSlider, {
            start: [500],
            step: 10,
            connect: [true, false],
            tooltips: [true],
            range: {
                'min': 0,
                'max': 1000
            },
            format: wNumb({
                decimals: 0,
                thousand: ',',
                prefix: '$ ',
            })
    });
  }
  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

  $('#register-form').validate({
    rules : {
        first_name : {
            required: true,
        },
        last_name : {
            required: true,
        },
        pass : {
            required: true
        },
        cpass : {
            required: true
        },
        email : {
            required: true,
            email : true
        },
        phone_number : {
            required: true,
        }
    },
    onfocusout: function(element) {
        $(element).valid();
    },
});

    jQuery.extend(jQuery.validator.messages, {
        required: "",
        password: "",
        email: "",
    });
})(jQuery);