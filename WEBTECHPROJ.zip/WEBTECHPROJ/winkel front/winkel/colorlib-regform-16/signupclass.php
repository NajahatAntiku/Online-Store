<?php

require('connectclass.php');
/**
*
*
*/
/**
 * 
 */
class shopper extends KDB

{
	//properties
	public $FN = null;
	public $LN = null;
	public $PS = null;
	public $EM = null;
	public $PN = null;
	
	function addNewUser($fname, $lname, $password, $email, $phonenumber)
	{
		$sql = "INSERT INTO User(`fname`,`lname`,`password`,`email`,`phonenumber`) VALUES ('$fname','$lname','$password','$email','$phonenumber')";
		return $this->dbquery($sql);
	}
}


?>