<?php
require('usertest.php');
echo "i work";
function clientype(){
	echo "I work";
	if (isset($_GET['vnd'])) {
		if (isset($_GET['Submit'])) {
			echo "I work";
			$first_name = $_GET['first_name'];
			$last_name = $_GET['last_name'];
			$password = $_GET['pass'];
			$email = $_GET['email'];
			$phone_number = $_GET['phone_number'];
			$name_of_shop = $_GET['NameS'];
			$category_of_shop = $_GET['Category'];


			$encrypt = password_hash($password, PASSWORD_DEFAULT);

			$appendToDb = regS($first_name, $last_name, $password, $email, $phone_number, $name_of_shop, $category_of_shop);

			if ($appendToDb) {
				echo "Sign Up Successful!";
				header("Location: /winkel/dashboard.html");

				$apToDb = addProductInfo($product_name, $Price);


			}else{
				echo "Access to this website is denied. Make sure to use an Ashesi email address.";
			}
	    }
    }else if (isset($_GET['shpr'])) {
		if (isset($_GET['Submit'])) {

		
			$first_name = $_GET['first_name'];
			$last_name = $_GET['last_name'];
			$password = $_GET['pass'];
			$email = $_GET['email'];
			$phone_number = $_GET['phone_number'];


			$encrypt = password_hash($password, PASSWORD_DEFAULT);

			$appendToDb = regU($first_name, $last_name, $password, $email, $phone_number);

			if ($appendToDb) {
				echo "Sign Up Successful!";
			}else{
				echo "Access to this website is denied. Make sure to use an Ashesi email address.";
			}
	    }
    }
}
	





?>