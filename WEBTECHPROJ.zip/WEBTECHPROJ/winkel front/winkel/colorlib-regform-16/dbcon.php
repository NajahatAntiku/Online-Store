<?php
//Defining constant variables

DEFINE('SEVERNAME','localhost');
DEFINE('USERNAME','root');
DEFINE('PASSWORD','');
DEFINE('DATABASE','aos');


?>