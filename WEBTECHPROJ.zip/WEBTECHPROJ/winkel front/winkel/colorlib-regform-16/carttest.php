<?php

require('SCclass.php');
session_start();

if (isset($_SESSION['cart'])) {
	$basket = $_SESSION['cart'];

}else{
	$basket = new ShoppingCart();
}

$1p = Product('90', 'Denim Jackbird Pullover', 'GHC 70.00', 'Clothing');
$2p = Product('4', 'kLS Pencil Case', 'GHC 10.00', 'Stationary');
$3p = Product('8', 'Indomie', 'GHC 10.00', 'Food');
$4p = Product('89', 'Michael Kors Hand Bag', 'GHC 100.00', 'Accessories');


$basket = addProduct(1p);
$basket = updateProduct(2p, 2);
$basket = deleteProduct(1p);

echo '<h2>Cart Contents (' . count($basket) . ' items)</h2>';
if (!$basket->isEmpty()) {
    foreach ($basket as $arr) {
        $product = $arr['product'];
        printf('<p><strong>%s</strong>: %d @ $%0.2f each.<p>', $product->getName(), $arr['qty'], $product->getPrice());
    } // End of foreach loop!
} 
?>