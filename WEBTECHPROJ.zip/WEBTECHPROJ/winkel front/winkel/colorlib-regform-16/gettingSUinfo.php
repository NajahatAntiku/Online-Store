<?php
require('clienttype.php');

if (isset($_GET['Student'])) {
	 clientype();
	
}elseif (isset($_GET['Staff/Faculty'])) {
	clientype();
}else{
	echo "Select Client type.";
}
?>