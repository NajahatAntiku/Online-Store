<?php


/**
 * 
 */
class vendor extends shopper
{
	public $FN = null;
	public $LN = null;
	public $PS = null;
	public $EM = null;
	public $PN = null;
	public $NS = null;
	public $CS = null;
	public $PrN = null;
	public $Price = 0;

	public function addNewSupplier($fname, $lname, $phonenumber, $password, $email,  $role, $ctype, $nameofsh, $categoryofsh){

		$sql = "INSERT INTO user(`FirstName`,`Surname`,`PhoneNumber`,`Password`,`Email`, `Category`, `Client Type`, `Name of Shop`, `Category of Shop`) VALUES ('$fname','$lname','$phonenumber','$password','$email','$role', '$ctype', '$nameofsh','$categoryofsh')";
		return $this->dbquery($sql);

	}
	public function addProductInfo($product_name, $Price){
		$sql = "INSERT INTO product(`Product Name`,`Price`) VALUES ('$product_name, $Price')";

		return $this->dbquery($sql);

	}
}


?>