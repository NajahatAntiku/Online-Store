<?php # Item.php


require('connectclass.php');

class Product {
	
	// Properties
	protected $id;
	protected $name;
	protected $price;
	protected $category;
	
	// Constructor populates the attributes:
	public function __construct($id, $name, $price, $category)	{
		$this->id = $id;
		$this->name = $name;
		$this->price = $price;
		$this->category = $category;
	}
	
	/**
	*
	*@return  returns the Id of the product
	*/ 
	public function getId()	{
		if (isset($_GET['addtocart1'])) {
			header("Location: cart.html");

		}
		return $this->id;
	}

	// Method that returns the name:
	public function getName() {
		$sql = SELECT `Product Name` FROM `product` WHERE 

		return $this->name;
	}

	// Method that returns the price:
	public function getPrice() {
		return $this->price;
	}



} 